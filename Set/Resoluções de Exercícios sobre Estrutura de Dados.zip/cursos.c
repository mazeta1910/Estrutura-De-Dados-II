#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cursos.h"

struct curso
{
    int id;
    char nome[100];
    Data* data_conclusao;
    char plataforma[50];
    Data* data_cadastro;
};

struct celula
{
    Curso curso;
    Celula *prox;
};

struct pilha
{
    Celula *topo;
};

Pilha* cria_Pilha()
{
    Pilha* pi = (Pilha*) malloc(sizeof(Pilha));
    if(pi != NULL)
    {
        pi->topo = NULL;
    }
    return pi;
}

int verificaPilhaVazia(Pilha* pi)
{
    return (pi->topo == NULL);
}

void empilha_Curso(Pilha* pi, int id, char* nome, Data* data_conclusao, char* plataforma)
{
    // Cria novo curso
    Curso novo;
    novo.id = id;
    strcpy(novo.nome, nome);
    novo.data_conclusao = data_conclusao;
    strcpy(novo.plataforma, plataforma);
    novo.data_cadastro = dataHoje(); // Data atual do cadastro
    
    // Cria nova célula
    Celula *nova = malloc(sizeof(Celula));
    nova->curso = novo;
    nova->prox = pi->topo;
    pi->topo = nova;
    
    printf("Curso cadastrado com sucesso!\n");
}

void desempilha_Curso(Pilha* pi)
{
    if(verificaPilhaVazia(pi))
    {
        printf("Erro: Pilha vazia!\n");
        return;
    }
    
    Celula *remover = pi->topo;
    pi->topo = remover->prox;
    
    // Libera as datas alocadas
    liberarData(remover->curso.data_conclusao);
    liberarData(remover->curso.data_cadastro);
    
    free(remover);
    printf("Curso removido com sucesso!\n");
}

void imprime_Pilha(Pilha* pi)
{
    if(verificaPilhaVazia(pi))
    {
        printf("Pilha vazia!\n");
        return;
    }
    
    Celula *aux = pi->topo;
    printf("\n=== CURSOS CONCLUÍDOS ===\n");
    while(aux != NULL)
    {
        printf("ID: %d\n", aux->curso.id);
        printf("Nome: %s\n", aux->curso.nome);
        printf("Data de Conclusão: ");
        imprimirData(aux->curso.data_conclusao);
        printf("\nPlataforma: %s\n", aux->curso.plataforma);
        printf("Data de Cadastro: ");
        imprimirData(aux->curso.data_cadastro);
        printf("\n----------------------\n");
        aux = aux->prox;
    }
}

void libera_Pilha(Pilha* pi)
{
    Celula *aux = pi->topo;
    Celula *liberar;
    while(aux != NULL)
    {
        liberar = aux;
        aux = aux->prox;
        
        // Libera as datas alocadas
        liberarData(liberar->curso.data_conclusao);
        liberarData(liberar->curso.data_cadastro);
        
        free(liberar);
    }
    free(pi);
}

