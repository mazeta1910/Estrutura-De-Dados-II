typedef struct jogo Jogo;
typedef struct celula Celula;
typedef struct lista Lista;

Lista* cria_Lista();
void libera_Lista(Lista* li);
int verificaListaVazia(Lista* li);
void insere_Lista(Lista* li, int codigo, char* nome, char* plataforma, int ano, char* estado);
void remove_Lista(Lista* li, int codigo);
int busca_Lista(Lista* li, int codigo);
void imprime_Lista(Lista* li);
Lista* copia_Finalizados(Lista* li);

