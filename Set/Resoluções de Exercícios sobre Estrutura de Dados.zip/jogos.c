#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "jogos.h"

struct jogo
{
    int codigo;
    char nome[100];
    char plataforma[20];
    int ano;
    char estado[20];
};

struct celula
{
    Jogo jogo;
    Celula *prox;
};

struct lista
{
    Celula *ini;
};

Lista* cria_Lista()
{
    Lista* li = (Lista*) malloc(sizeof(Lista));
    if(li != NULL)
    {
        li->ini = NULL;
    }
    return li;
}

int verificaListaVazia(Lista* li)
{
    return (li->ini == NULL);
}

void insere_Lista(Lista* li, int codigo, char* nome, char* plataforma, int ano, char* estado)
{
    // Verifica se já existe um jogo com o mesmo código
    if(busca_Lista(li, codigo))
    {
        printf("Erro: Jogo com código %d já existe!\n", codigo);
        return;
    }
    
    // Cria novo jogo
    Jogo novo;
    novo.codigo = codigo;
    strcpy(novo.nome, nome);
    strcpy(novo.plataforma, plataforma);
    novo.ano = ano;
    strcpy(novo.estado, estado);
    
    // Cria nova célula
    Celula *nova = malloc(sizeof(Celula));
    nova->jogo = novo;
    nova->prox = li->ini;
    li->ini = nova;
}

void remove_Lista(Lista* li, int codigo)
{
    if(verificaListaVazia(li))
    {
        printf("Erro: Lista vazia!\n");
        return;
    }
    
    Celula *atual = li->ini;
    Celula *anterior = NULL;
    
    while(atual != NULL && atual->jogo.codigo != codigo)
    {
        anterior = atual;
        atual = atual->prox;
    }
    
    if(atual == NULL)
    {
        printf("Erro: Jogo com código %d não encontrado!\n", codigo);
        return;
    }
    
    if(anterior == NULL) // Remove o primeiro
    {
        li->ini = atual->prox;
    }
    else
    {
        anterior->prox = atual->prox;
    }
    
    free(atual);
    printf("Jogo com código %d removido com sucesso!\n", codigo);
}

int busca_Lista(Lista* li, int codigo)
{
    Celula *aux = li->ini;
    while(aux != NULL)
    {
        if(aux->jogo.codigo == codigo)
        {
            return 1; // Encontrado
        }
        aux = aux->prox;
    }
    return 0; // Não encontrado
}

void imprime_Lista(Lista* li)
{
    if(verificaListaVazia(li))
    {
        printf("Lista vazia!\n");
        return;
    }
    
    Celula *aux = li->ini;
    printf("\n=== LISTA DE JOGOS ===\n");
    while(aux != NULL)
    {
        printf("Código: %d\n", aux->jogo.codigo);
        printf("Nome: %s\n", aux->jogo.nome);
        printf("Plataforma: %s\n", aux->jogo.plataforma);
        printf("Ano: %d\n", aux->jogo.ano);
        printf("Estado: %s\n", aux->jogo.estado);
        printf("----------------------\n");
        aux = aux->prox;
    }
}

Lista* copia_Finalizados(Lista* li)
{
    Lista* nova_lista = cria_Lista();
    
    if(verificaListaVazia(li))
    {
        return nova_lista;
    }
    
    Celula *aux = li->ini;
    while(aux != NULL)
    {
        if(strcmp(aux->jogo.estado, "Finalizado") == 0)
        {
            insere_Lista(nova_lista, aux->jogo.codigo, aux->jogo.nome, 
                        aux->jogo.plataforma, aux->jogo.ano, aux->jogo.estado);
        }
        aux = aux->prox;
    }
    
    return nova_lista;
}

void libera_Lista(Lista* li)
{
    Celula *aux = li->ini;
    Celula *liberar;
    while(aux != NULL)
    {
        liberar = aux;
        aux = aux->prox;
        free(liberar);
    }
    free(li);
}

