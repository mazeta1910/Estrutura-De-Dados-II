#include <stdio.h>
#include <stdlib.h>
#include "cursos.h"

int main()
{
    Pilha* pilha_cursos = cria_Pilha();
    int opcao, id, dia, mes, ano;
    char nome[100], plataforma[50];
    Data* data_conclusao;
    
    do
    {
        printf("\n=== MENU CURSOS ONLINE ===\n");
        printf("1 - Inserir novo curso\n");
        printf("2 - Excluir curso\n");
        printf("3 - Imprimir todos os cursos\n");
        printf("4 - Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);
        
        switch(opcao)
        {
            case 1:
                printf("Digite o ID do curso: ");
                scanf("%d", &id);
                printf("Digite o nome do curso: ");
                scanf(" %[^\n]", nome);
                printf("Digite o dia de conclusão: ");
                scanf("%d", &dia);
                printf("Digite o mês de conclusão: ");
                scanf("%d", &mes);
                printf("Digite o ano de conclusão: ");
                scanf("%d", &ano);
                data_conclusao = dataNova(dia, mes, ano);
                printf("Digite a plataforma (Coursera, Udemy, Alura, edX, ou outra): ");
                scanf(" %[^\n]", plataforma);
                empilha_Curso(pilha_cursos, id, nome, data_conclusao, plataforma);
                break;
                
            case 2:
                desempilha_Curso(pilha_cursos);
                break;
                
            case 3:
                imprime_Pilha(pilha_cursos);
                break;
                
            case 4:
                printf("Saindo...\n");
                break;
                
            default:
                printf("Opção inválida!\n");
        }
    } while(opcao != 4);
    
    libera_Pilha(pilha_cursos);
    
    return 0;
}

