#include <stdio.h>
#include <stdlib.h>
#include "jogos.h"

int main()
{
    Lista* lista_jogos = cria_Lista();
    Lista* lista_finalizados = NULL;
    int opcao, codigo, ano;
    char nome[100], plataforma[20], estado[20];
    
    do
    {
        printf("\n=== MENU JOGOS DIGITAIS ===\n");
        printf("1 - Inserir novo jogo\n");
        printf("2 - Excluir jogo\n");
        printf("3 - Buscar jogo\n");
        printf("4 - Imprimir todos os jogos\n");
        printf("5 - Copiar jogos finalizados\n");
        printf("6 - Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);
        
        switch(opcao)
        {
            case 1:
                printf("Digite o código do jogo: ");
                scanf("%d", &codigo);
                printf("Digite o nome do jogo: ");
                scanf(" %[^\n]", nome);
                printf("Digite a plataforma (PC, PS5, Xbox, Switch, Mobile): ");
                scanf(" %[^\n]", plataforma);
                printf("Digite o ano de lançamento: ");
                scanf("%d", &ano);
                printf("Digite o estado (Finalizado, Jogando, Por jogar): ");
                scanf(" %[^\n]", estado);
                insere_Lista(lista_jogos, codigo, nome, plataforma, ano, estado);
                break;
                
            case 2:
                printf("Digite o código do jogo a ser removido: ");
                scanf("%d", &codigo);
                remove_Lista(lista_jogos, codigo);
                break;
                
            case 3:
                printf("Digite o código do jogo a ser buscado: ");
                scanf("%d", &codigo);
                if(busca_Lista(lista_jogos, codigo))
                {
                    printf("Jogo encontrado!\n");
                }
                else
                {
                    printf("Jogo não encontrado!\n");
                }
                break;
                
            case 4:
                imprime_Lista(lista_jogos);
                break;
                
            case 5:
                if(lista_finalizados != NULL)
                {
                    libera_Lista(lista_finalizados);
                }
                lista_finalizados = copia_Finalizados(lista_jogos);
                printf("Lista de jogos finalizados criada!\n");
                imprime_Lista(lista_finalizados);
                break;
                
            case 6:
                printf("Saindo...\n");
                break;
                
            default:
                printf("Opção inválida!\n");
        }
    } while(opcao != 6);
    
    libera_Lista(lista_jogos);
    if(lista_finalizados != NULL)
    {
        libera_Lista(lista_finalizados);
    }
    
    return 0;
}

