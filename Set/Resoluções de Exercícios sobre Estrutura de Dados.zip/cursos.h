#include "Data.h"

typedef struct curso Curso;
typedef struct celula Celula;
typedef struct pilha Pilha;

Pilha* cria_Pilha();
void libera_Pilha(Pilha* pi);
int verificaPilhaVazia(Pilha* pi);
void empilha_Curso(Pilha* pi, int id, char* nome, Data* data_conclusao, char* plataforma);
void desempilha_Curso(Pilha* pi);
void imprime_Pilha(Pilha* pi);

